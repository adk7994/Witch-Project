import random
import os.path
hasItem= 0
currentRoom = 0
hasKey = 0
win = 0
bossHp=3
atkMod = 0
playerHp = 2
bossDead = False
hasDiary = False
def fileOpen(file):
    infile = open(file, 'r')
    outputFile = infile.read()
    print (outputFile)
    
def bossLose():
    print ("You have defeated Gorlock! \nYou gain 1/2 level of experience.\nGorlock was concealing a magic key. \nMaybe the key opens the chest in the bedroom. ")
    isInteger = True
    hasKey = 1
    nextRoom = 0
    while nextRoom == 0:
        leave = input("Press enter to return to the kitchen")
        try:
            if leave == "":
                nextRoom = 1
                currentRoom = 3
        except:
            print("Please hit Enter")
def gameOver():
    input ("Why did you pick the options you chose?")
    
while win == 0 :
    if currentRoom == 0:
        #this plays whenever the player enters the scenario phase of the game
        scenario = "scenario.txt"
        infile = open(scenario,'r')
        outputFile = infile.read()
        print (outputFile)
        nextRoom=0
        while nextRoom==0:
            option = input("Press Enter to continue")
            try:
                if option == "":
                   nextRoom=1
                   currentRoom=1
                else:
                    print ("Response was not Enter")
            except:
                print("Response was not Enter")
                
                

    if currentRoom == 1:
        #this plays whenever the player enters the outside of the cabin portion of the game
        isInteger = False
        settingOff = "setting.txt"
        infile = open(settingOff,'r')
        outputFile = infile.read()
        print (outputFile)
        while isInteger == False:
            option = input("What do you want to do?  1. [open the door] or 2. [Flee]")
            try:
                int(option)
                print ("You chose option ", option)
                isInteger = True
                if int(option) == 2:
                    print ("Game Over, you lose!")
                    win = 1
                else:
                    currentRoom=2
            except:
                print ("Please input an integer value")
    if currentRoom == 2:
        #this plays whenever the player enters that first room in the cabin
        isInteger = False
        theEncounter = "encounter.txt"
        infile = open(theEncounter, 'r')
        outputFile = infile.read()
        print (outputFile)
        tablecheck = False
        if hasItem == 1:
            tablecheck = True
        while tablecheck == False:
            option = input ("Do you wish to search the messy table or open a door?   1. [Search]    2. [Doors]")
            try:
                int (option)
                print ("You chose option ", option)
                tablecheck = True
                if int(option) == 1:
                    hasItem = 1
                    print ("You found The Bracelet of Accuracy!")
                    fileOpen("bracelet.txt")
                else:
                    tablecheck=True
            except:
                print ("Please input a response as an Integer")
                
        while isInteger == False:
            option = input ("Which door do you wish to open?     1. [Left]     2. [Right]")
            try:
                int(option)
                print ("You chose option ", option)
                if int(option) == 1:
                    currentRoom=3
                    isInteger = True
                elif int(option)==2:
                    isInteger = True
                    currentRoom = 4
            except:
                print ("Please enter an integer value")
    if currentRoom ==3:
        # sets the current room to the Kitchen
        isInteger = False
        kitchen = "kitchen.txt"
        infile = open(kitchen, 'r')
        outputFile = infile.read()
        print (outputFile)
        while isInteger == False:
            option = input ("What would you like to do?   1. [Search]   2. [Exit the room]   3. [Proceed to Basement] ")
            try :
                int(option)
                print ("You chose option " , option)
                if int(option)==1:
                    print("There is nothing of interest in the room.")
                elif int(option)==2:
                    isInteger = True
                    currentRoom = 2
                elif int(option) == 3:
                    isInteger = True
                    currentRoom = 5
            except:
                print ("Please input an integer response.")
    if currentRoom == 6:
            # This is the "Game Over" room that helps escape some of the loops from other rooms
            gameOver()
            win = 1
            #While the player has not actually won, this variable will keep the game going unless it is changed to 1
    if currentRoom  == 4:
        #The following code is everything that happens in the bedroom
        isInteger = False
        bedroom = "bedroom.txt"
        infile = open(bedroom, 'r')
        outputFile = infile.read()
        print (outputFile)
        while isInteger == False:
            option = input("What would you like to do?    1. [Search]   2. [Exit the room]  3. [Open the Chest]")
            try:
                int(option)
                print ("You chose " , option)
                if int(option) == 1:
                    hasDiary = True
                    print ("There seems to be a hidden bottom in Gorlock's nightstand. Inside you find a book and open it.")
                    fileOpen("diary.txt")
                elif int(option) == 2:
                    isInteger = True
                    currentRoom = 2
                elif int(option) == 3:
                    if hasKey == 0:
                        print ("The chest is locked and you do not have the key!")
                    elif hasKey == 1:
                        isInteger = True
                        print ("You have received the Potion of Protection!")
                        fileOpen("potion.txt")
                        print ("You Win!")
                        win = 1
                        
            except:
                print("Please input an integer response.")
    if win == 1:
        gameOver()
    if currentRoom == 5:
        #All the code for the basement.
        if bossDead== False:
            basement = "basement.txt"
            infile = open(basement, 'r')
            outputFile = infile.read()
            print(outputFile)
            persuade = 0
            cure = 0
            #has fear is a variable that makes sure that the 2nd option is only attemptable once
            while bossDead == False:
                option = input ("What do you wish to do?   1. [Attack]    2. [Persuade]    3.[Perception]")
                try:
                    int(option)
                    print ("You chose", int(option))
                    if hasItem ==1:
                           atkMod = 1
                    if int(option) == 1:
                           playerDice = random.randrange(20)+1
                           playerTotal = playerDice + atkMod
                           print ("Your roll was " , playerDice, " with a modifier of +", atkMod)
                           if playerDice == 20:
                                bossHp=0
                                print("You got a critical hit!")
                           elif playerDice == 1:
                                bossHp=bossHp-1
                                print ("Critical Failure, Gorlock has ", bossHp, "Hp left" )
                           elif playerTotal >=12:
                                bossHp=bossHp-2
                                print ("You've hit Gorlock!  Gorlock has ", bossHp, "Hp left")
                           if bossHp >0:
                                   gorlockDice = random.randrange(20)-1
                                   if gorlockDice >=12:
                                       playerHp=playerHp-1
                                       print ("Gorlock rolled a " , gorlockDice+2, " with a modifier of -2. Gorlock strikes you and does 1 damage! Your health is now " , playerHp)
                                   else:
                                       print ("Gorlock rolled a " , gorlockDice+2, " with a modifier of -2. Gorlock misses you entirely!")
                           elif bossHp <=0:
                               bossDead = True
                               bossLose()
                               bossDead = True
                               currentRoom = 3
                               hasKey = 1
                           if playerHp <=0:
                                bossDead = True
                                currentRoom = 6
                                bossDead = True
                                print ("You were slain by Gorlock The Warlock!!")
                except:
                    print ("Please enter an integer response")
                try:
                    if int(option) == 2:
                        #attempts to persuade Gorlock that you do not fear him.
                        if persuade == 0:
                            playerDice = random.randrange(20)+1
                            gorlockDice = random.randrange(20)+5
                            print ("You attempt to persuade Gorlock that you do not fear him.")
                            print ("You rolled a " , playerDice, " vs Gorlock's " , gorlockDice)
                            if playerDice > gorlockDice:
                                print ("You were successful! Gorlock no longer fears you and thus his powers no longer affect you.\nGorlock surrenders in fear.")
                                bossDead = True
                                bossLose()
                                bossDead = True
                                currentRoom = 3
                                hasKey = 1
                            else:
                                print ("Gorlock does not believe you")
                            persuade =1
                        elif persuade ==1:
                            print ("You have already attempted to persuade Gorlock, further attempts won't work.")


                            
                    if int(option) == 3:
                        if cure == 0 and hasDiary==0:
                            cure = 1
                            playerDice = random.randrange(20)+1
                            gorlockDice = random.randrange(20)+1
                            gorlockTotal = gorlockDice -2
                            print ("You attempt to take a closer look at Gorlock")
                            print("You rolled a ", playerDice, " against Gorlock's ", gorlockDice, "but he has a -2 modifier! His total is ", gorlockTotal)
                            if playerDice > gorlockTotal:
                                print ("You notice that Gorlock is unwell and if you cured him you could save him.\nYou cure his ailment and Gorlock no longer wishes to harm you.")
                                bossDead=True
                                bossLose()
                                hasKey = 1
                                bossDead=True
                                currentRoom = 3
                            else:
                                print("You don't notice anything strange about Gorlock other than he is ugly.")
                        elif cure == 1 and hasDiary==0:
                            print ("You have already attempted to consider Gorlock more carefully and cannot do it again.")
                        elif hasDiary == 1:
                            print("Based on the diary that you've read, you know that Gorlock is afflicted by an ailment that makes him evil.\nYou cure his ailment and Gorlock no longer wishes to harm you.")
                            bossDead = True
                            bossLose()
                            hasKey = 1
                            currentRoom = 3
                except:
                    print("Please input an integer response")
        elif bossDead == True:
            
               print ("You have already defeated Gorlock and have no reason to be in the basement anymore.\nYou decided to climb back up the stairs to the kitchen.")
               currentRoom = 3
#The github is             https://github.com/adk7994/Witch-Project
                
            
            
                            
